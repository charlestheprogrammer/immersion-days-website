import random

lastPlay = -1 #-1 if less, 1 if more, 0 if good
lastInput = -1 # your last input


def nextTurn(maxRange):
    pass