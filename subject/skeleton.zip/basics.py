def perroquet(count, string):
    pass


def factorielle(n):
    pass



def fibonacci(n):
    pass