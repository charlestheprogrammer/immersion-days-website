def checknumber(inputgiven , number):
    pass


def game(target, tryN):
    pass
